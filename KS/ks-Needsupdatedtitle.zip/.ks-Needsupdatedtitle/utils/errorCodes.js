module.exports = {
    FILE_NOT_FOUND: 40645,
    UNSUPPORTED_OPERATION: 105,
    USER_WARNING: 10
};
